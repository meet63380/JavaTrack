import torch
from torchvision import transforms 
import torch.nn.functional as F
import numpy as np

from PIL import Image

"""
def horisontal_flip(images, targets):
    images = torch.flip(images, [-1])
    targets[:, 2] = 1 - targets[:, 2]
    return images, targets
"""

def horisontal_flip(images, targets=None):
    images = torch.flip(images, [-1])
    if targets==None:
      return images
    targets[:, 2] = 1 - targets[:, 2]
    return images, targets

def augment_color(images):
    """
    Brightness: value x uniform( max(0,1-brightness), 1+brigtness )
                if setting brightness as tuple like (b1,b2), value x uniform(b1,b2)
    Contrast: value x uniform( max(0,1-contrast), 1+contrast )
              if setting contrast as tuple like (c1,c2), value x uniform(c1,c2)
    Saturation: value x uniform( max(0,1-saturation), 1+saturation )
              if setting contrast as tuple like (s1,s2), value x uniform(s1,s2)
    Hue: value x uniform( max(0,1-hue), 1+hue )
              if setting contrast as tuple/list like (h1,h2), value x uniform(h1,h2)
    """
    transform = transforms.ColorJitter(brightness=0.5, contrast=0.5, saturation=0.5, hue=(-0.1,0.1))
 
    images = transform(images)

    #images = transforms.ToTensor()(images)

    return images
