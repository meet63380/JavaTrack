# -*- coding: utf-8 -*-
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.autograd import Function,Variable
import numpy as np

#from utils.parse_config import *
from utils.utils import build_targets, to_cpu, non_max_suppression

import matplotlib.pyplot as plt
import matplotlib.patches as patches



class YOLOLayer(nn.Module):
    """Detection layer"""


    def __init__(self, anchors, num_classes, img_dim=(480,480)):
        super(YOLOLayer, self).__init__()
        self.anchors = anchors
        self.num_anchors = len(anchors)
        self.num_classes = num_classes
        self.ignore_thres = 0.5
        self.mse_loss = nn.MSELoss()
        self.bce_loss = nn.BCELoss()
        self.obj_scale = 1
        self.noobj_scale = 100
        self.metrics = {}
        self.img_dim = img_dim
        #self.img_dim_w = img_dim[1]
        #self.img_dim_h = img_dim[0]
        self.grid_size = (0,0)  # grid size

    def compute_grid_offsets(self, grid_size, cuda=True):
        self.grid_size = grid_size
        g = self.grid_size
        FloatTensor = torch.cuda.FloatTensor if cuda else torch.FloatTensor
        self.stride_w = self.img_dim[1] / self.grid_size[1]
        self.stride_h = self.img_dim[0] / self.grid_size[0]
        # Calculate offsets for each grid
        self.grid_x = torch.arange(g[1]).repeat(g[0], 1).view([1, 1, g[0], g[1]]).type(FloatTensor)
        self.grid_y = torch.arange(g[0]).repeat(g[1], 1).t().view([1, 1, g[0], g[1]]).type(FloatTensor)

        self.scaled_anchors = FloatTensor([(a_w / self.stride_w, a_h / self.stride_h) for a_w, a_h in self.anchors])
        self.anchor_w = self.scaled_anchors[:, 0:1].view((1, self.num_anchors, 1, 1))
        self.anchor_h = self.scaled_anchors[:, 1:2].view((1, self.num_anchors, 1, 1))

    def forward(self, x, targets=None, img_dim=None):
        print(x.is_cuda)
        # Tensors for cuda support
        FloatTensor = torch.cuda.FloatTensor if x.is_cuda else torch.FloatTensor
        LongTensor = torch.cuda.LongTensor if x.is_cuda else torch.LongTensor
        ByteTensor = torch.cuda.ByteTensor if x.is_cuda else torch.ByteTensor
        print(FloatTensor, type(torch.cuda.FloatTensor), type(torch.FloatTensor))
        #self.img_dim_w = img_dim[0]
        #self.img_dim_h = img_dim[1]
        num_samples = x.size(0)
        grid_size = (x.size(2),x.size(3))#h,w
        #print(x.size())

        prediction = (
            x.view(num_samples, self.num_anchors, self.num_classes + 5, grid_size[0], grid_size[1])
            .permute(0, 1, 3, 4, 2) #torch.permute() rearranges the original tensor according to the desired ordering and returns a new multidimensional rotated tensor. The size of the returned tensor remains the same as that of the original.
            .contiguous()
        )

        # Get outputs
        x = torch.sigmoid(prediction[..., 0])  # Center x
        y = torch.sigmoid(prediction[..., 1])  # Center y
        w = prediction[..., 2]  # Width
        h = prediction[..., 3]  # Height
        pred_conf = torch.sigmoid(prediction[..., 4])  # Conf
        pred_cls = torch.sigmoid(prediction[..., 5:])  # Cls pred.
        #print("Get Outputs",x,y,w,h,pred_conf,pred_cls)
        #print(self.grid_x)
        # If grid size does not match current we compute new offsets
        if grid_size != self.grid_size:
            self.compute_grid_offsets(grid_size, cuda=x.is_cuda)

        # Add offset and scale with anchors
        pred_boxes = FloatTensor(prediction[..., :4].shape)  #.... means (N,S,S,25) ?
        pred_boxes[..., 0] = x.data + self.grid_x
        pred_boxes[..., 1] = y.data + self.grid_y
        pred_boxes[..., 2] = torch.exp(w.data) * self.anchor_w
        pred_boxes[..., 3] = torch.exp(h.data) * self.anchor_h

        #stride = FloatTensor(torch.tensor([self.stride_w,self.stride_h,self.stride_w,self.stride_h]))
        stride = torch.tensor([self.stride_w,self.stride_h,self.stride_w,self.stride_h])
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        stride = stride.to(device)


        output = torch.cat(
            (
                pred_boxes.view(num_samples, -1, 4) * stride,
                pred_conf.view(num_samples, -1, 1),
                pred_cls.view(num_samples, -1, self.num_classes),
            ),
            -1,
        )

        if targets is None:
            return output, 0
        else:
            iou_scores, class_mask, obj_mask, noobj_mask, tx, ty, tw, th, tcls, tconf = build_targets(
                pred_boxes=pred_boxes,
                pred_cls=pred_cls,
                target=targets,
                anchors=self.scaled_anchors,
                ignore_thres=self.ignore_thres,
            )
            #print("Targets",targets)
            # Loss : Mask outputs to ignore non-existing objects (except with conf. loss)
            loss_x = self.mse_loss(x[obj_mask], tx[obj_mask])
            loss_y = self.mse_loss(y[obj_mask], ty[obj_mask])
            loss_w = self.mse_loss(w[obj_mask], tw[obj_mask])
            loss_h = self.mse_loss(h[obj_mask], th[obj_mask])
            loss_conf_obj = self.bce_loss(pred_conf[obj_mask], tconf[obj_mask])
            loss_conf_noobj = self.bce_loss(pred_conf[noobj_mask], tconf[noobj_mask])
            loss_conf = self.obj_scale * loss_conf_obj + self.noobj_scale * loss_conf_noobj
            loss_cls = self.bce_loss(pred_cls[obj_mask], tcls[obj_mask])
            total_loss = loss_x + loss_y + loss_w + loss_h + loss_conf + loss_cls

            # Metrics
            cls_acc = 100 * class_mask[obj_mask].mean()
            conf_obj = pred_conf[obj_mask].mean()
            conf_noobj = pred_conf[noobj_mask].mean()
            conf50 = (pred_conf > 0.5).float()
            iou50 = (iou_scores > 0.5).float()
            iou75 = (iou_scores > 0.75).float()
            detected_mask = conf50 * class_mask * tconf
            precision = torch.sum(iou50 * detected_mask) / (conf50.sum() + 1e-16)
            recall50 = torch.sum(iou50 * detected_mask) / (obj_mask.sum() + 1e-16)
            recall75 = torch.sum(iou75 * detected_mask) / (obj_mask.sum() + 1e-16)

            self.metrics = {
                "loss": to_cpu(total_loss).item(),
                "x": to_cpu(loss_x).item(),
                "y": to_cpu(loss_y).item(),
                "w": to_cpu(loss_w).item(),
                "h": to_cpu(loss_h).item(),
                "conf": to_cpu(loss_conf).item(),
                "cls": to_cpu(loss_cls).item(),
                "cls_acc": to_cpu(cls_acc).item(),
                "recall50": to_cpu(recall50).item(),
                "recall75": to_cpu(recall75).item(),
                "precision": to_cpu(precision).item(),
                "conf_obj": to_cpu(conf_obj).item(),
                "conf_noobj": to_cpu(conf_noobj).item(),
                "grid_size": grid_size,
            }
            #print("Detection matrix is ",self.metrics)
            return output, total_loss


class ObjectDetection(nn.Module):

    def __init__(self, cfg):
        super(ObjectDetection, self).__init__()

        # self.phase = phase
        self.cfg = cfg
        #self.img_size_x, self.img_size_y = self.cfg['input_size']
        self.img_size = self.cfg['input_size']
        self.num_classes = self.cfg['num_classes']
        self.anchors = self.cfg['anchors']
        self.in_channels = self.cfg['in_channels']

        #a deconvolutional layer is put on top of regular CNN. The down-sampled response maps from CNN are upsampled
        # through this deconvolution layer, producing the feature that can be used to predict class labels at all the
        # pixel locations.
        self.deconv1 = nn.Sequential(
            nn.ConvTranspose2d(self.in_channels[1], 320, kernel_size=(2,2), stride=2,groups=320),
            nn.BatchNorm2d(320, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True)
        )


        self.conv2_1 = nn.Sequential(
            nn.Conv2d(self.in_channels[1], self.in_channels[0], kernel_size=(1, 1), stride=(1, 1), padding=(0, 0), bias=False),
            nn.BatchNorm2d(self.in_channels[0], eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True)
        )

        self.deconv2_1 = nn.Sequential(
            nn.ConvTranspose2d(self.in_channels[0], self.in_channels[0], kernel_size=(2,2), stride=2),
            nn.BatchNorm2d(96, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True)
        )

        self.conv2_2 = nn.Sequential(
            nn.Conv2d(self.in_channels[0], 128, kernel_size=(1, 1), stride=(1, 1), padding=(0, 0), bias=False),
            nn.BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True)
        )

        self.deconv2 = nn.Sequential(
            nn.ConvTranspose2d(128, 128, kernel_size=(2,2), stride=2,groups=128),
            nn.BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True))

        self.detection_layers = self.detectionLayer(self.cfg)

        self.yolo_layers = []
        self.yolo_layers.append(YOLOLayer(list(self.cfg['anchors'])[0:3], self.num_classes, self.img_size))
        self.yolo_layers.append(YOLOLayer(list(self.cfg['anchors'])[3:6], self.num_classes, self.img_size))
        self.seen = 0

    def detectionLayer(self, cfg):

        num_classes = cfg['num_classes']
        masks = cfg['masks']
        in_channels = cfg['in_channels']
        num_det_layers = cfg['num_of_detection_layers']

        detection_layers = []
        detection_layers += [nn.Conv2d(320, len(masks[1])*(num_classes+5), kernel_size=(1, 1))]
        detection_layers += [nn.Conv2d(128, len(masks[0])*(num_classes+5), kernel_size=(1, 1))]

        return nn.ModuleList(detection_layers)

    def forward(self, x, targets=None):

        f_outputs = []
        out = self.deconv1(x[3])
        #print("x[3]",x[3].size())
        f_outputs.append(out)

        x_m = self.conv2_1(x[3])
        x_m = self.deconv2_1(x_m)
        x_m = x_m + x[2]
        x_m = self.conv2_2(x_m)
        out = self.deconv2(x_m)
        f_outputs.append(out)

        ## Detection
        loss = 0
        yolo_outputs = []
        detectionLayerOutputs=[]
        for ii, (ff, dd, yy) in enumerate(zip(f_outputs, self.detection_layers, self.yolo_layers)):
            dets, layer_loss = yy(dd(ff), targets, self.img_size)
            loss += layer_loss
            yolo_outputs.append(dets)
            detectionLayerOutputs.append(dd(ff))
        #print("YOLO LAyers",detectionLayerOutputs)

        yolo_outputs = to_cpu(torch.cat(yolo_outputs, 1))
        return yolo_outputs if targets is None else (loss, yolo_outputs)
        #return detectionLayerOutputs
