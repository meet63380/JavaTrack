from __future__ import division
from pathlib import Path
# from models import *
from utils.utils import *
from utils.datasets import *
from utils.parse_config import *

import os
import sys
import time
import datetime
import argparse
import tqdm
import re
import torch
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision import transforms
from torch.autograd import Variable
import torch.optim as optim
#from pycocotools.cocoeval import COCOeval


# def test(model, path, iou_thres, conf_thres, nms_thres, img_size, batch_size):
#     cocoEval = COCOeval()
#     cocoEval.evaluate()
#     cocoEval.accumulate()
#     #cocoEval.summarize()
def save_one_json(predn, jdict, path, class_map):
    # Save one JSON result {"image_id": 42, "category_id": 18, "bbox": [258.15, 41.29, 348.26, 243.78], "score": 0.236}
    # image_id = int(path.stem) if path.stem.isnumeric() else path.stem
    image_id = re.findall(r'\w+(?=\.)',str(path))[0]
    box = xyxy2xywh(predn[:, :4])  # xywh
    box[:, :2] -= box[:, 2:] / 2  # xy center to top-left corner
    for p, b in zip(predn.tolist(), box.tolist()):
        jdict.append({'image_id': image_id,
                      'category_id': class_map[int(p[5])],
                      'bbox': [round(x, 3) for x in b],
                      'score': round(p[4], 5)})
def evaluate(model, path, iou_thres, conf_thres, nms_thres, img_size, batch_size):
    model.eval()

    # Get dataloader
    dataset = ListDataset(path, img_size=img_size, augment_flip=False, multiscale=False,augment_color=False)
    # print("test dataset is ",dataset, type(dataset))
    dataloader = torch.utils.data.DataLoader(
        dataset, batch_size=batch_size, shuffle=False, num_workers=1, collate_fn=dataset.collate_fn
    )

    Tensor = torch.cuda.FloatTensor if torch.cuda.is_available() else torch.FloatTensor
    #print("dataloader",dataloader.size())

    # for batch_i, (imgs, targets) in enumerate(tqdm(dataloader, desc='Computing mAP')):
    #     print("pass")
    jdict=[]
    labels = []
    sample_metrics = []  # List of tuples (TP, confs, pred)
    for batch_i, (imgpath, imgs,targets) in enumerate(tqdm.tqdm(dataloader, desc="Detecting objects")):
        # print("X",imgpath)
        # print("targets",targets)
        # print("imags",imgs)
        # Extract labels

        labels += targets[:, 1].tolist()
        # print("Labels are",labels)
        # Rescale target
        targets[:, 2:] = xywh2xyxy(targets[:, 2:])
        targets[:, 2:] *= torch.tensor([img_size[0], img_size[1], img_size[0], img_size[1]])
        imgs = Variable(imgs.type(Tensor), requires_grad=False)
        # print("images are",imgs)
        class_map = coco80_to_coco91_class()
        with torch.no_grad():
            outputs = model(imgs)
            outputs = non_max_suppression(outputs, conf_thres=conf_thres, nms_thres=nms_thres)
            for si, pred in enumerate(outputs):
                predn = pred.clone()
                save_one_json(predn, jdict,imgpath, class_map)
            with open("output/pred.json", 'w') as f:
                json.dump(jdict, f)
            anno_json = "cocoPersonCatDog/6 classes_annotations.json"
            pred_json = "output/pred.json"
            try:  # https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocoEvalDemo.ipynb
                from pycocotools.coco import COCO
                from pycocotools.cocoeval import COCOeval

                anno = COCO(anno_json)  # init annotations api
                pred = anno.loadRes(pred_json)  # init predictions api
                eval = COCOeval(anno, pred, 'bbox')
                eval.params.imgIds = [int(Path(x).stem) for x in
                                      dataloader.dataset.img_files]  # image IDs to evaluate
                eval.evaluate()
                eval.accumulate()
                eval.summarize()
                map, map50 = eval.stats[:2]  # update results (mAP@0.5:0.95, mAP@0.5)
            except Exception as e:
                print(f'pycocotools unable to run: {e}')
            #outputs = np.array(outputs)
        # outputs[:,:4] = xywh2xyxy(outputs[:,:4])
        # print("Type of outputs", outputs)

        sample_metrics += get_batch_statistics(outputs, targets, iou_threshold=iou_thres)
        # print("öutput shape",outputs.size())
        # print("targets shape", targets.size())
        # ar = compute_ar(targets,outputs, [0.5] * len(targets))



    try:
        # Concatenate sample statistics
        true_positives, pred_scores, pred_labels = [np.concatenate(x, 0) for x in list(zip(*sample_metrics))]
        precision, recall, AP, f1, ap_class = ap_per_class(true_positives, pred_scores, pred_labels, labels)

        # cocoEval = COCOeval(GT,PV,'bbox')
        # eva = cocoEval.evaluate()pip install pycocotools-windows
        # acceva = cocoEval.accumulate()

    except ValueError:
        print(sample_metrics)

    return precision, recall, AP, f1, ap_class


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch_size", type=int, default=8, help="size of each image batch")
    parser.add_argument("--model_def", type=str, default="config/yolov3.cfg", help="path to model definition file")
    parser.add_argument("--data_config", type=str, default="config/coco.data", help="path to data config file")
    parser.add_argument("--weights_path", type=str, default="weights/yolov3.weights", help="path to weights file")
    parser.add_argument("--class_path", type=str, default="data/coco.names", help="path to class label file")
    parser.add_argument("--iou_thres", type=float, default=0.5, help="iou threshold required to qualify as detected")
    parser.add_argument("--conf_thres", type=float, default=0.001, help="object confidence threshold")
    parser.add_argument("--nms_thres", type=float, default=0.5, help="iou thresshold for non-maximum suppression")
    parser.add_argument("--n_cpu", type=int, default=8, help="number of cpu threads to use during batch generation")
    parser.add_argument("--img_size", type=int, default=(480, 480), help="size of each image dimension")
    opt = parser.parse_args()
    print(opt)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    data_config = parse_data_config(opt.data_config)
    valid_path = data_config["valid.txt"]
    class_names = load_classes(data_config["names"])

    # Initiate model
    model = Darknet(opt.model_def).to(device)
    if opt.weights_path.endswith(".weights"):
        # Load darknet weights
        model.load_darknet_weights(opt.weights_path)
    else:
        # Load checkpoint weights
        model.load_state_dict(torch.load(opt.weights_path))

    print("Compute mAP...")

    precision, recall, AP, f1, ap_class = evaluate(
        model,
        path=valid_path,
        iou_thres=opt.iou_thres,
        conf_thres=opt.conf_thres,
        nms_thres=opt.nms_thres,
        img_size=opt.img_size,
        batch_size=8,
    )

    print("Average Precisions:")
    for i, c in enumerate(ap_class):
        print(f"+ Class '{c}' ({class_names[c]}) - AP: {AP[i]}")

    print(f"mAP: {AP.mean()}")
