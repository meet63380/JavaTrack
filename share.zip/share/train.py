from __future__ import division

#from models import *
#from utils.logger import *
from utils.utils import *
from utils.datasets import *
from utils.parse_config import *
from test import evaluate
#from pycocotools.cocoeval import COCOeval

from terminaltables import AsciiTable

import os
import sys
import time
import datetime
import argparse

import torch
from torch.nn import init
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision import transforms
import torch.nn.functional as F
from torch.autograd import Variable
import torch.optim as optim

from subModules import backBone,detection

#import cv2
import numpy as np

# Setting default values
objectdetection_cfg={
    'num_classes':4,
    'input_size':(480,480),#(256,384)
    'num_strides':(5,6),
    'detection_featuremap_size':((60,60),(30,30)),
    'num_anchors':6,
    #'anchors':((10,10),(10,20),(50,50),(50,100),(200,200),(200,350)),
    'anchors':((10,10),(10,20),(50,50),(50,100),(200,200),(200,350)),
    'masks':((0,1,2),(3,4,5)),
    'in_channels':(96,320),
    'num_of_detection_layers':2
}

#torch.nn.Module - It is a base class used to develop all neural network models.
#Pytorch uses a torch.nn base class which can be used to wrap parameters, functions, and layers in the torch.nn modules.

# def load_check(checkpoint):
#     # for key, value in checkpoint.items():
#     #     print(key)
#     # #print(checkpoint)
#     model.load_state_dict(checkpoint['state_dict'])
#     #print(model)




class MultiTask(nn.Module):
  def __init__(self):
    super(MultiTask, self).__init__()
    # Calling backbone and Object detection functions
    self.backbone = backBone.myBackbone()
    #print("backbone called")
    self.objdet = detection.ObjectDetection(objectdetection_cfg)#object detection
    #print("Detection called")
  # Any deep learning model is developed using the subclass of the torch.nn module it uses method like
  # forward(input) which returns the output

  def forward(self,im,targets=None):
    #im = im[0].to(self.device)
    #print(im[0])
    x = self.backbone(im)  # passing the inputs
    obj_out = self.objdet(x,targets)
    #print("out",obj_out)
    return obj_out


if __name__ == "__main__":

    # Taking arguments from user
    # The argparse module also automatically generates help and usage messages and issues errors when users give the program invalid arguments
    parser = argparse.ArgumentParser()
    # Python argparse is a command-line parsing module that is recommended to work with the command line argument

    parser.add_argument("--epochs", type=int, default=1, help="number of epochs")
    parser.add_argument("--batch_size", type=int, default=16, help="size of each image batch")
    parser.add_argument("--gradient_accumulations", type=int, default=1, help="number of gradient accums before step")
    #parser.add_argument("--model_def", type=str, default="config/yolov3.cfg", help="path to model definition file")
    parser.add_argument("--data_config", type=str, default="cocoPersonCatDog/dataset.data", help="path to data config file")
    parser.add_argument("--pretrained_weights", type=str, default="checkpoints/pretrained/backbone_pretrained_detco.pth", help="if specified starts from checkpoint model")
    parser.add_argument("--n_cpu", type=int, default=2, help="number of cpu threads to use during batch generation")
    parser.add_argument("--img_size", type=int, default=(480,480), nargs='+',help="size of each image dimension")
    parser.add_argument("--checkpoint_interval", type=int, default=10, help="interval between saving model weights")
    parser.add_argument("--evaluation_interval", type=int, default=10, help="interval evaluations on validation set")
    parser.add_argument("--compute_map", default=False, help="if True computes mAP every tenth batch")
    #We can generate anchor boxes with different numbers and sizes on multiple scales to detect objects of different sizes on multiple scales.
    #https://d2l.djl.ai/chapter_computer-vision/multiscale-object-detection.html?msclkid=2f437e24a77911eca628469d22883341
    parser.add_argument("--multiscale_training", default=False, help="allow for multi-scale training")
    parser.add_argument("--resume_epoch", default=0, help="allow for multi-scale training")

    opt = parser.parse_args()
    opt.img_size = tuple(opt.img_size)
    print(opt)

    #logger = Logger("logs")

    #checking for the CUDA
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    #An integer representing the number of CPUs present in the system
    print('cpu_count():', os.cpu_count())
    print('device:', device)
    #torch.backends.cudnn.benchmark = True

    torch.backends.cudnn.benchmark = False

    #It enables benchmark mode in cudnn.
    #benchmark mode is good whenever your input sizes for your network do not vary. This way, cudnn will look for the optimal set of algorithms for that particular configuration (which takes some time). This usually leads to faster runtime.
    #But if your input sizes changes at each iteration, then cudnn will benchmark every time a new size appears, possibly leading to worse runtime performances.

    print(torch.backends.cudnn.benchmark) # = True

    #Creating Ouput and Checkpoints Directory
    os.makedirs("output", exist_ok=True)
    os.makedirs("checkpoints", exist_ok=True)

    # Get data configuration
    data_config = parse_data_config(opt.data_config)
    train_path = data_config["train"]
    valid_path = data_config["valid"]
    class_names = load_classes(data_config["names"])

    # Initiate model
    model = MultiTask().to(device)
    model.train()
    #print(model)
    #print("tensor",model(torch.rand(1,3,480,480)).shape)


    # Get dataloader
    #ListDataset - Returns a list of datasets in the current workspace

    dataset = ListDataset(train_path, augment_flip=True, augment_color=True, multiscale=opt.multiscale_training)
    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=opt.batch_size,
        shuffle=True,
        num_workers=opt.n_cpu,
        pin_memory=True, # this technique requires that the OS is willing to give the PyTorch process as much main memory as it needs to complete its load and transform operations—e.g. the batch must fit into RAM in its entirety.
        collate_fn=dataset.collate_fn, # converts NumPy arrays in PyTorch tensors
        #prefetch_factor=2,
    )

    # Using Adam Optimizer
    #optimizer = torch.optim.Adam(model.parameters())
    optimizer = torch.optim.Adadelta(model.parameters())

    # If specified we start from checkpoint
    if opt.pretrained_weights:
        print('load pretrained model from checkpoint')
        ckp = torch.load(opt.pretrained_weights,map_location=torch.device('cpu'))
        #state_dict is simply a Python dictionary object that maps each layer to its parameter tensor.
        # It is used to load or save the models
        if 'state_dict' in ckp:
           model.backbone.load_state_dict(ckp['state_dict'],strict=False) # checks for the backbone otherwise use the pretrained models
           #optimizer.load_state_dict(ckp['optimizer'])
        else:
           model.backbone.load_state_dict(ckp,strict=False)

    else:
      ## initialize model
      print('model initialization')

    #It will initialize the weights and bias in the entire nn.Module recursively.
      def weights_init(m):
        if isinstance(m, nn.Conv2d):
            init.kaiming_normal_(m.weight.data)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0.0)

      #using weights in the backbone and object detection
      model.backbone.apply(weights_init)
      model.objdet.apply(weights_init)

    metrics = [
        "grid_size",
        "loss",
        "x",
        "y",
        "w",
        "h",
        "conf",
        "cls",
        "cls_acc",
        "recall50",
        "recall75",
        "precision",
        "conf_obj", # presence of object
        "conf_noobj", #no of objects
    ]
    dataset_test = ListDataset(valid_path, augment_flip=False, augment_color=False)

    # Training the Model
    # dataloader_test = torch.utils.data.DataLoader(
    #     dataset_test,
    #     batch_size=opt.batch_size,
    #     shuffle=True,
    #     num_workers=opt.n_cpu,
    #     pin_memory=True,
    #     collate_fn=dataset.collate_fn,
    #
    # )
    start_epoch=int(opt.resume_epoch)

    for epoch in range(start_epoch,opt.epochs):
        model.train()
        start_time = time.time()
        loss_accumulate = 0
        for batch_i, (impath, imgs, targets) in enumerate(dataloader):
            #print('1:')
            batches_done = len(dataloader) * epoch + batch_i
            # print("batches done",batches_done)

            imgs = Variable(imgs.to(device))
            targets = Variable(targets.to(device), requires_grad=False)

            objdet_out = model(imgs, targets)
            # print(objdet_out)
            loss, output = objdet_out
            # print(output)


            print('train loss:',loss)
            loss.backward()

            if batches_done % opt.gradient_accumulations:
                # Accumulates gradient before each step
                optimizer.step()
                optimizer.zero_grad()


            # ----------------
            #   Log progress
            # ----------------

            log_str = "\n---- [Epoch %d/%d, Batch %d/%d] ----\n" % (epoch, opt.epochs, batch_i, len(dataloader))


            metric_table = [["Metrics" , *[f"YOLO Layer {i}" for i in range(len(model.objdet.yolo_layers))]]]


            log_str += AsciiTable(metric_table).table
            log_str += f"\nTotal loss {loss.item()}"

            # Determine approximate time left for epoch
            epoch_batches_left = len(dataloader) - (batch_i + 1)
            time_left = datetime.timedelta(seconds=epoch_batches_left * (time.time() - start_time) / (batch_i + 1))
            log_str += f"\n---- ETA {time_left}"

            print("log_str",log_str)

        #model, path, iou_thres, conf_thres, nms_thres, img_size, batch_size

        precision, recall, AP, f1, ap_class = evaluate(model,valid_path,iou_thres=0.5,conf_thres=0.4,nms_thres=0.4,img_size=(480,480),batch_size=1)
        print("Results",precision, recall, AP, f1, ap_class)
        print("Precision", precision)
        print("recall", recall)
        print("AP", AP)
        print("f1", f1)
        print("AP Class", ap_class)
        # print("AR",ar)
        #print("acca",acceva)
        # Saving the Weights
        if epoch % opt.checkpoint_interval == 0:
            checkpoint = {
               'state_dict': model.state_dict(),
               'optimizer': optimizer.state_dict()
            }

            #torch.save(model.state_dict(), f"checkpoints/yolov3_ckpt_%d.pth" % epoch)
            #torch.save(checkpoint, f"checkpoints/orochi_model_ckpt_%d.pth" % epoch)

        if epoch == (opt.epochs - 1):
            torch.save(checkpoint, f"checkpoints/orochi_model_%d_final.pth" % epoch)






    # model.eval()
    # tloss = 0
    # correct = 0
    # l = []
    #
    # for batch_i, (impath, imgs,targets) in enumerate(dataloader_test):
    #     print("image",impath)
    #     print("targets",targets)
    #     batches_done = len(dataloader_test) * epoch + batch_i
    #     # print(batches_done)
    #     imgs = Variable(imgs.to(device))
    #     targets = Variable(targets.to(device), requires_grad=False)
    #
    #     objdet_out_test = model(imgs)
    #     print(objdet_out_test[0].size())
        #print("output is", objdet_out_test)
    #     for i in range(len(objdet_out_test)):
    #          l.append(torch.tensor(i))
    #          print(l)
    #     test_tensor = torch.tensor(l)
    #     print("type of result",type(test_tensor))
    #    # print(l)
    #
    #     #tloss += F.nll_loss(objdet_out_test,targets)
    #
    #     tloss = F.mse_loss(objdet_out_test, targets)
    #     print("tloss",tloss)
    #     pred = objdet_out_test.imgs.max(1,keepdim=True)[1]
    #     print("pred",pred)
    #     correct += pred.eq(targets.imgs.view_As(pred)).sum()
    #     print("correct",correct)
    #     output_test = objdet_out_test[0]
    # print(output_test.size())

    #load_check(torch.load(r'D:\Nikon AI\share\checkpoints\orochi_model_0_final.pth'))




# 1. Commenting the imports that are not used
# 2. Changing number of epochs from 200 to a small number
# 3. Changed --data_config default value to the path of my .data file
# 4. loss, output = objdet_out[0]
# 5. model.objdet.yolo_layers