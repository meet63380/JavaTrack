# -*- coding: utf-8 -*-


import torch
import torch.nn as nn
# Used Backbone- MobileNetv2

class myBackbone(nn.Module):
    def __init__(self):
        super(myBackbone, self).__init__()

        #Sometimes your residual hasn’t the same output’s dimension, so we cannot add them.
        # We can project the input using a conv in the shortcut (the black arrow with the +) to match your output’s
        # feature

        # shortcut  =  sum of ip and op and use the summary of the op of the whole block to get better propagation of gradients

        self.shortcut = [3,5,6,8,9,10,12,13,15,16]
        self.outputLayer = [3,6,13,17,18]

        layers = []
    #It is a sequential Container used to combine different layers to create a feed-forward network.

        l0 = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=(3, 3), stride=(2, 2), padding=(1, 1), bias=False),
            nn.BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True)
        )
        layers.append(l0)

        l1 = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), groups=32, bias=False),
            nn.BatchNorm2d(32, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True),
            nn.Conv2d(32, 16, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.BatchNorm2d(16, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        )
        layers.append(l1)

        expansion_param = 6

        l2 = self.InvertedResidual(16,24,expansion_param,2)
        layers.append(l2)

        l3 = self.InvertedResidual(24,24,expansion_param,1)
        layers.append(l3)

        l4 = self.InvertedResidual(24,32,expansion_param,2)
        layers.append(l4)

        l5 = self.InvertedResidual(32,32,expansion_param,1)
        layers.append(l5)

        l6 = self.InvertedResidual(32,32,expansion_param,1)
        layers.append(l6)

        l7 = self.InvertedResidual(32,64,expansion_param,2)
        layers.append(l7)

        l8 = self.InvertedResidual(64,64,expansion_param,1)
        layers.append(l8)

        l9 = self.InvertedResidual(64,64,expansion_param,1)
        layers.append(l9)

        l10 = self.InvertedResidual(64,64,expansion_param,1)
        layers.append(l10)

        l11 = self.InvertedResidual(64,96,expansion_param,1)
        layers.append(l11)

        l12 = self.InvertedResidual(96,96,expansion_param,1)
        layers.append(l12)

        l13 = self.InvertedResidual(96,96,expansion_param,1)
        layers.append(l13)

        l14 = self.InvertedResidual(96,160,expansion_param,2)
        layers.append(l14)

        l15 = self.InvertedResidual(160,160,expansion_param,1)
        layers.append(l15)

        l16 = self.InvertedResidual(160,160,expansion_param,1)
        layers.append(l16)

        l17 = self.InvertedResidual(160,320,expansion_param,1)
        layers.append(l17)

        l18 = nn.Sequential(
            nn.Conv2d(320, 1280, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.BatchNorm2d(1280, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True)
        )
        layers.append(l18)

        self.modules_list = nn.ModuleList(layers)


    def InvertedResidual(self,in_c,out_c,t,s):
      module = nn.Sequential(
            nn.Conv2d(in_c, in_c*t, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.BatchNorm2d(in_c*t, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True),
            nn.Conv2d(in_c*t, in_c*t, kernel_size=(3, 3), stride=(s, s), padding=(1, 1), groups=in_c*t, bias=False),
            nn.BatchNorm2d(in_c*t, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True),
            nn.ReLU6(inplace=True),
            nn.Conv2d(in_c*t, out_c, kernel_size=(1, 1), stride=(1, 1), bias=False),
            nn.BatchNorm2d(out_c, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
            )

      return module


    def forward(self, x):

      out = []
      for i,f in enumerate(self.modules_list):
        tmp_x = f(x)
        if i in self.shortcut:
          x = x+tmp_x
        else:
          x = tmp_x

        if i in self.outputLayer:
          out.append(x)


      return out
