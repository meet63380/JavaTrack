# -*- coding: utf-8 -*-

import numpy as np


data1 = np.load('../out/backbone_o1.npy')
data2 = np.load('../out/backbone_o1.npy')

dummy = np.random.rand(data1.shape[0],data1.shape[1],data1.shape[2],data1.shape[3])

print(np.allclose(data1,data1))
print(np.allclose(data1,dummy))
